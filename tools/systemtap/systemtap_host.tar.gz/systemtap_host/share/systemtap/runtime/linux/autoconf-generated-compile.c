#include <generated/compile.h>

char* x = UTS_VERSION;

